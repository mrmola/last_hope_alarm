//TODO: ADD TIME ZONE

#include "Arduino.h"
#include <EEPROM.h>
#include "lighting_library.h"
#include "time.h"
#include "ESP32Time.h"

#define SHORTPRESSTHRESH 250 //In milliseconds

//EEPROM offsets of these values 
#define TIMEOFFSET 0
#define REDOFFSET 6

int hourToSleep = 0;
ESP32Time rtc(0);
STATE currentState = OFF;
const char* ntpServer = "pool.ntp.org";
int gmtTimeHours = -5;

int timeToBeRed = 30*60;
int timeToGoOff = 0;
int permTimeToGoOff = 0;

float brightnessModifier = 1.0;

struct buttonPress {
  int lastFalling; //WHEN THE BUTTON WAS PRESSED
  uint8_t checkMe; //TREAT THIS LIKE A BOOLEAN ITS WHETHER IT SHOULD BE CHECKED. 
               //IF CHECKME IS GREATER THAN 0 THEN IT IS THE TIME THE BUTTON WAS RELEASED
} buttonState;
float lerp(float a, float b, float v) {
    return (a + (b-a)*v);
}

//This is for persistent memory
void storeIntToEEPROM(int input, int offset) {
  uint8_t* bytes = (uint8_t*) &input;
  EEPROM.write(0+offset, bytes[0]);
  EEPROM.write(1+offset, bytes[1]);
  EEPROM.write(2+offset, bytes[2]);
  EEPROM.write(3+offset, bytes[3]);
}

int readIntFromEEPROM(int offset) {
  uint8_t bytes[4];
  bytes[0] = EEPROM.read(0+offset);
  bytes[1] = EEPROM.read(1+offset);
  bytes[2] = EEPROM.read(2+offset);
  bytes[3] = EEPROM.read(3+offset);
  return (int) *bytes;
}

void set_red(unsigned int _input)
{
	ledcWrite(ledChannel_R, RED_R_INTEN*_input);
	ledcWrite(ledChannel_G, RED_G_INTEN*_input);
	ledcWrite(ledChannel_B, RED_B_INTEN*_input);
}

void set_white(unsigned int _input)
{
	ledcWrite(ledChannel_R, WHITE_R_INTEN*_input);
	ledcWrite(ledChannel_G, WHITE_G_INTEN*_input);
	ledcWrite(ledChannel_B, WHITE_B_INTEN*_input);
}
//Please fix fading this is peeving me
void red_to_white(unsigned int _input)
{
	ledcWrite(ledChannel_R, RED_R_INTEN*_input);
	ledcWrite(ledChannel_G, RED_G_INTEN*_input);
	ledcWrite(ledChannel_B, RED_B_INTEN*_input);
	for (int dutyCycle = 0; dutyCycle <= _input; dutyCycle++)
	{
        ledcWrite(ledChannel_R, lerp(RED_R_INTEN,WHITE_R_INTEN,((float)dutyCycle)/((float)_input))*_input);
        ledcWrite(ledChannel_G, lerp(RED_G_INTEN,WHITE_G_INTEN,((float)dutyCycle)/((float)_input))*_input);
        ledcWrite(ledChannel_B, lerp(RED_B_INTEN,WHITE_B_INTEN,((float)dutyCycle)/((float)_input))*_input);
        delay(ceil(((float)FADE_TIME_MS)/((float)_input)));
	}
}

void white_to_red(unsigned int _input)
{
  Serial.println("WHITE_TO_RED");
	ledcWrite(ledChannel_R, WHITE_R_INTEN*_input);
	ledcWrite(ledChannel_G, WHITE_G_INTEN*_input);
	ledcWrite(ledChannel_B, WHITE_B_INTEN*_input);
	for (int dutyCycle = 0; dutyCycle <= _input; dutyCycle++)
	{
        ledcWrite(ledChannel_R, lerp(WHITE_R_INTEN,RED_R_INTEN,((float)dutyCycle)/((float)_input))*_input);
        ledcWrite(ledChannel_G, lerp(WHITE_G_INTEN,RED_G_INTEN,((float)dutyCycle)/((float)_input))*_input);
        ledcWrite(ledChannel_B, lerp(WHITE_B_INTEN,RED_B_INTEN,((float)dutyCycle)/((float)_input))*_input);
        delay(ceil(((float)FADE_TIME_MS)/((float)_input)));
	}
}

void red_to_off(unsigned int _input)
{
  Serial.println("RED_TO_OFF");
	ledcWrite(ledChannel_R, RED_R_INTEN*_input);
	ledcWrite(ledChannel_G, RED_G_INTEN*_input);
	ledcWrite(ledChannel_B, RED_B_INTEN*_input);
	for (int dutyCycle = 0; dutyCycle <= _input; dutyCycle++)
	{
        ledcWrite(ledChannel_R, lerp(RED_R_INTEN,0,((float)dutyCycle)/((float)_input))*_input);
        ledcWrite(ledChannel_G, lerp(RED_G_INTEN,0,((float)dutyCycle)/((float)_input))*_input);
        ledcWrite(ledChannel_B, lerp(RED_B_INTEN,0,((float)dutyCycle)/((float)_input))*_input);
        delay(ceil(((float)FADE_TIME_MS)/((float)_input)));
	}
}

void shut_off()
{
	ledcWrite(ledChannel_R, 0);
	ledcWrite(ledChannel_G, 0);
	ledcWrite(ledChannel_B, 0);
}

int sensor(){
    int analogValue =  analogRead(PHOTORESISTORPIN);
    float voltage = analogValue * 5/4095.0;
    float resistance = 2000 * voltage / (1 - voltage / 5);
    float lux = pow(RL10 * 1e3 * pow(10, GAMMA) / resistance, (1 / GAMMA));
    lux=lux/1300*1000;
    return lux;
}

//TESTME
void calibRTCTime() {
  struct tm timeinfo;
  if(!getLocalTime(&timeinfo)){
    Serial.println("Failed to obtain time");
    return;
  }
  rtc.setTimeStruct(timeinfo);	
  Serial.println(&timeinfo, "%A, %B %d %Y %H:%M:%S");
  return;
}
//The function the handle the button being pressed. REMOVE THE SERIAL FROM HERE JOHN
void IRAM_ATTR isr() {
  int k = digitalRead(BUTTONPIN);
  Serial.println("BRUHHH");
  if(k > 0) {
    buttonState.checkMe = millis();
  } else {
    buttonState.lastFalling = millis();
  }
}

void initialize() {
  Serial.println("INTIALIZATION STARTED");
  //Initialize persistent memory
  EEPROM.begin(10);
  Serial.println("EEPROM INITIALIZED");
  Serial.println("RIGHT BEFORE CALIBRATING NTP TIME");
  //Calibrate the time to be accurate with an NTP server (standardized time server);
  configTime(gmtTimeHours*60*60, 0, ntpServer);
  //Initialize the times. Why is this not working. 
  timeToBeRed = readIntFromEEPROM(REDOFFSET);
  permTimeToGoOff = readIntFromEEPROM(TIMEOFFSET);
  timeToGoOff = permTimeToGoOff;

  Serial.println("RIGHT BEFORE CALIBRATING RTC TIME");
  calibRTCTime();
  Serial.println("FINISHED INITIALIZATION, LETS ROLL");
  pinMode(redLED, OUTPUT);
  pinMode(greenLED, OUTPUT);
  pinMode(blueLED, OUTPUT);
  Serial.println("BEGAN LED SETUP");
  ledcSetup(ledChannel_R, freq*10, resolution);
  Serial.println("FR");
  ledcSetup(ledChannel_G, freq*10, resolution);
  Serial.println("FG");
  ledcSetup(ledChannel_B, freq*10, resolution);
  Serial.println("FB");
  ledcAttachPin(redLED, ledChannel_R);
  ledcAttachPin(greenLED, ledChannel_G);
  ledcAttachPin(blueLED, ledChannel_B);

  pinMode(PHOTORESISTORPIN, INPUT);
  //The pin we attaching the button to
	pinMode(BUTTONPIN, INPUT_PULLUP);
	attachInterrupt(BUTTONPIN, isr, CHANGE);
}

//TEST ME
int secondsIntoDay() {
  return ((rtc.getSecond()+rtc.getMinute()*60+rtc.getHour()*60*60)*60)%(24*60*60);
}
#define ISRED(A) A == RED || A == FORCED_RED || A == CHANGED_TIME_RED
#define ISWHITE(A) A == WHITE || A == FORCED_WHITE || A == CHANGED_TIME_WHITE
void changeState(STATE newState) {
  Serial.printf("STATE %d to %d\n", currentState, newState);
  //ADD FADING
  if(ISRED(newState)) {
    if(ISWHITE(currentState)) white_to_red(MAX_INTEN*brightnessModifier);
    else set_red();
  }
  if(ISWHITE(newState)) {
    if(ISRED(currentState)) red_to_white(MAX_INTEN*brightnessModifier);
    else set_white();
  }
  if(newState == OFF) {
    if(ISRED(currentState)) red_to_off(MAX_INTEN*brightnessModifier);
    set_white(0);
    timeToGoOff=permTimeToGoOff;
  }
  currentState = newState;
}

int getTimeToGoOff() {
  return permTimeToGoOff;
}

int getRedTime() {
  return timeToBeRed;
}

void setTime(int seconds) {
  permTimeToGoOff = seconds;
  timeToGoOff =  permTimeToGoOff;
  storeIntToEEPROM(seconds, TIMEOFFSET);
  Serial.printf("SECONDS STORED: %D\n", seconds);
  Serial.println(rtc.getTime("TIME: %A, %B %d %Y %H:%M:%S"));
}

void setRedTime(int seconds) {
  timeToBeRed = seconds; 
  storeIntToEEPROM(seconds, REDOFFSET);
  Serial.printf("SECONDS STORED: %D", seconds);
}

void bumpTime(int amount) {
  timeToGoOff += amount;
}

void lightLogic(unsigned int time) {
  if(sensor() > 50) {
    brightnessModifier = 0.2;
  } else if (sensor() < 4) {
    brightnessModifier =  1.;
  } else {
    brightnessModifier =  0.7;
  }
  if(ISRED(currentState)) brightnessModifier = 1.;

  //THIS CODE GETS RUN IN THE LOOP
  //HERES
  unsigned int light_inten=sensor();
  //Handles setting the light
  if(ISRED(currentState)) {
    //Serial.println("ITS RED");
    set_red(MAX_INTEN*brightnessModifier);
  }
  if(ISWHITE(currentState)) {
    //Serial.println("ITS WHITE");
    set_white(MAX_INTEN*brightnessModifier);
  }
  if(currentState == OFF) {
    //Serial.println("ITS OFF");
    set_white(0);
  }
  //Switch statement for all the states
  switch(currentState) {
    case RED: 
      if(time > timeToGoOff) {
        changeState(OFF);
      }
      if(buttonState.checkMe > 0){
        buttonState.checkMe = 0;
        changeState(OFF);
      }
      //In case the time has been changed
      if(time < timeToGoOff-timeToBeRed) {
        changeState(WHITE);
      }
      break;
    case WHITE:
      if(time > timeToGoOff-timeToBeRed) {
        changeState(RED);
      }
      if(buttonState.checkMe > 0){
        buttonState.checkMe = 0;
        changeState(OFF);
      }
      break;
    case OFF:
      if(buttonState.checkMe > 0){
        buttonState.checkMe = 0;
        changeState(WHITE);
      }
      break;
    case FORCED_RED:
      if(buttonState.checkMe > 0){
        buttonState.checkMe = 0;
        changeState(OFF);
      }
      break;
    case FORCED_WHITE:
      if(buttonState.checkMe > 0){
        buttonState.checkMe = 0;
        changeState(OFF);
      }
     break;
    default:
      Serial.println("This should never be reahced");
      break;
  }
}