#include <Arduino.h>


#include "WiFi.h"
#include "time.h"
#include "ESPAsyncWebServer.h"
#include "SPIFFS.h"
#include "lighting_library.h"


#define SLEEP_DATA_HEADER_NAME "DATA"
#define TIME_DATA_HOUR_NAME "HOURS"
#define TIME_DATA_MINUTE_NAME "MINUTES"
#define WAIT_TIME_HEADER "MINUTES"
// Replace with your network credentials
const char* ssid = "joe (2)";
const char* password = "aaaaaaaa";

// Set LED GPIO
const int ledPin = 2;
// Stores LED state
String ledState;

// Create AsyncWebServer object on port 80
AsyncWebServer server(80);
void setup(){
  // Serial port for debugging purposes
  Serial.begin(115200);
  Serial.println("gottem");
  // Initialize SPIFFS
  if(!SPIFFS.begin(true)){
    Serial.println("An Error has occurred while mounting SPIFFS");
    return;
  }

  // Connect to Wi-Fi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connecting to WiFi..");
  }

  // Print ESP32 Local IP Address
  Serial.println(WiFi.localIP());

  // Route for root / web page
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(SPIFFS, "/1.html", String(), false, nullptr);
  });

  server.on("/stuff.js", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(SPIFFS, "/stuff.js", String(), false, nullptr);
  });
  //This input gets thrown into the garbage, we don't care. 
  server.on("/SLEEP_VALUE", HTTP_POST, [](AsyncWebServerRequest *request){
    int headers = request->headers();
    int i;
    char inputValue[3];
    for(i=0;i<headers;i++){
      AsyncWebHeader* h = request->getHeader(i);
      if(strcmp(h->name().c_str(),SLEEP_DATA_HEADER_NAME)==0){ 
        strcpy(inputValue, h->value().c_str());
      }
    }
    Serial.printf("SLEEP VALUE: %s\n", inputValue);
    //SAVE WHATEVER THE INPUT IS HERE
    request->send(200, "text/plain", "NICE JOB!");
  });
  //The time at which they wish to go to sleep. Why is it named wakeupvalue???
  server.on("/WAKEUP_VALUE", HTTP_POST, [](AsyncWebServerRequest *request){
    int headers = request->headers();
    int i;
    char hours[30];
    char minutes[30];
    for(i=0;i<headers;i++){
      AsyncWebHeader* h = request->getHeader(i);
      if(strcmp(h->name().c_str(),TIME_DATA_MINUTE_NAME)==0){ 
        strcpy(minutes, h->value().c_str());
      }
      if(strcmp(h->name().c_str(),TIME_DATA_HOUR_NAME)==0){ 
        
        strcpy(hours, h->value().c_str());
      } 
    }
    int hour = atoi(hours);
    int minute = atoi(minutes);
    Serial.printf("HOURS: %s %d   MINUTES: %s %d\n", hours, hour, minutes, minute);
    setTime(hour*60*60+minute*60);
    //SAVE WHATEVER THE INPUT IS HERE
    request->send(200, "text/plain", "NICE JOB!");
  });

  server.on("/WAIT_TIME", HTTP_POST, [](AsyncWebServerRequest *request){
    int headers = request->headers();
    int i;
    char minutes[30];
    for(i=0;i<headers;i++){
      AsyncWebHeader* h = request->getHeader(i);
      if(strcmp(h->name().c_str(),WAIT_TIME_HEADER)==0){ 
        strcpy(minutes, h->value().c_str());
      }
    }
    int seconds = atoi(minutes)*60;
    Serial.printf("MINUTES: %s SECONDS: %d\n", minutes, seconds);
    setRedTime(seconds);
    //SAVE WHATEVER THE INPUT IS HERE
    request->send(200, "text/plain", "NICE JOB!");
  });

  server.on("/ON", HTTP_POST, [](AsyncWebServerRequest *request){
      Serial.printf("ON");
      changeState(FORCED_WHITE);
    //SAVE WHATEVER THE INPUT IS HERE
    request->send(200, "text/plain", "NICE JOB!");
  });  
  server.on("/OFF", HTTP_POST, [](AsyncWebServerRequest *request){
      Serial.printf("OFF");
      changeState(OFF);
    //SAVE WHATEVER THE INPUT IS HERE
    request->send(200, "text/plain", "NICE JOB!");
  });
  server.on("/RED", HTTP_POST, [](AsyncWebServerRequest *request){
      Serial.printf("RED  ");
      changeState(FORCED_RED);
    //SAVE WHATEVER THE INPUT IS HERE
    request->send(200, "text/plain", "NICE JOB!");
  });
  server.on("/WHITETIME", HTTP_GET, [](AsyncWebServerRequest *request){
      Serial.printf("TIME_REQUEST  ");
      char toSend[100];
      itoa(getTimeToGoOff(), toSend, 10);
      //SAVE WHATEVER THE INPUT IS HERE
      request->send(200, "text/plain", toSend);
  });
  server.on("/REDTIME", HTTP_GET, [](AsyncWebServerRequest *request){
      Serial.printf("TIME_REQUEST  ");
      char toSend[100];
      itoa(getRedTime(), toSend, 10);
      //SAVE WHATEVER THE INPUT IS HERE
      request->send(200, "text/plain", toSend);
  });
  server.on("/TIME", HTTP_GET, [](AsyncWebServerRequest *request){
      Serial.printf("TIME_REQUEST  ");
      char toSend[100];
      itoa(secondsIntoDay(), toSend, 10);
      //SAVE WHATEVER THE INPUT IS HERE
      request->send(200, "text/plain", toSend);
  });
  //Increase wakeup time
  server.on("/BUMP_TIME", HTTP_POST, [](AsyncWebServerRequest *request){
    int headers = request->headers();
    int i;
    char minutes[30];
    for(i=0;i<headers;i++){
      AsyncWebHeader* h = request->getHeader(i);
      if(strcmp(h->name().c_str(),WAIT_TIME_HEADER)==0){ 
        strcpy(minutes, h->value().c_str());
      }
    }
    int seconds = atoi(minutes)*60;
    Serial.printf("MINUTES: %s SECONDS: %d\n", minutes, seconds);
    bumpTime(seconds);
    //SAVE WHATEVER THE INPUT IS HERE
    request->send(200, "text/plain", "NICE JOB!");
  });
  // Start server
  Serial.println("GOING");
  server.begin();
  Serial.println("GOING");
  initialize();
  Serial.println("GONE!");
  pinMode(ledPin, OUTPUT);
}
 
void loop(){
  lightLogic(secondsIntoDay());
  Serial.printf("Photoresistor output: %d\n", sensor());
  delay(100);
}
