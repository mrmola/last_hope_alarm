#ifndef LIGHTING
#define LIGHTING

#define MAX_INTEN 1023
#define WHITE_inten 1023
#define WHITE_R_INTEN 1.
#define WHITE_G_INTEN 1.
#define WHITE_B_INTEN 1.
#define RED_R_INTEN 1.
#define RED_B_INTEN 0.
#define RED_G_INTEN 0.
#define FADE_TIME_MS 1000
#define freq 5000
#define resolution  10
#define redLED       25                      // the pin for the RED LED
#define greenLED     32                      // the pin for the GREEN LED
#define blueLED      33                      // the pin for the YELLOW LED
#define ledChannel_R 0
#define ledChannel_G 1
#define ledChannel_B 2
#define BUTTONPIN 17
#define PHOTORESISTORPIN 35

#define GAMMA 0.7
#define RL10  50

enum STATE {
    OFF, 
    RED, 
    WHITE, 
    FORCED_RED, 
    FORCED_WHITE,
    CHANGED_TIME_WHITE, 
    CHANGED_TIME_RED
};

void begin();
void set_red(unsigned int _input = WHITE_inten);
void set_white(unsigned int _input = WHITE_inten);
void red_to_white(unsigned int _input = WHITE_inten);
void white_to_red(unsigned int _input = WHITE_inten);
void fade(float red, float white, unsigned int _input = WHITE_inten);
void shut_off();

int getTimeToGoOff();
int getRedTime();
int secondsIntoDay();

void setTime(int seconds);
void setRedTime(int seconds);
void bumpTime(int amount);
int sensor();
void initialize();
void changeState(STATE newState);
void lightLogic(unsigned int time);
#endif